<div class="container">
	<div class="row">
		<div class="col-md-8">
    <h2>Bienvenido a InFlask</h2>
    <p>Con tu <b>Cuenta de InFlask</b> podras tener acceso a servicios unicos.</p>
    <ul>
      <li><b> Prueba Gratis</b> podras probar cualquiera de nuestro software GRATIS por un periodo de 3 meses.</li>
      <li><b> Acceso beta</b> respaldos y copias de seguridad de sus bases de datos continuos, se entrega una copia al cliente y se guarda una copia extra.</li>
      <li><b> Ticket de soporte</b> tickets de soporte y consultas gratis.</li>
      <li><b> Super descuentos</b> descuentos al comprar cualquiera de nuestras aplicaciones.</li>
    </ul>
    <br><br><br>
    </div>
    <div class="col-md-4">
<h4>CUENTA DE INFLASK</h4>
<hr>
<form class="form-horizontal" method="post" action="client-login.php" role="form">

  <div class="form-group">
    <div class="col-md-12">
        <label for="exampleInputEmail1">Correo electronico</label>
      <input type="text" name="email" class="form-control" id="inputEmail1" placeholder="Correo Electronico">
    </div>
  </div>
  <div class="form-group">
    <div class="col-md-12">
    <label for="exampleInputEmail1">Contrase&ntilde;a</label>
      <input type="password" name="password" class="form-control" id="inputEmail1" placeholder="Escribe tu nombre">
    </div>
  </div>

  <div class="form-group">
    <div class="col-lg-12">
      <button type="submit" class="btn btn-block btn-default">Acceder</button>
    </div>
  </div>
  <div class="form-group">
    <div class="col-lg-12">
      <a href="./inflask-account" class="btn btn-block btn-primary">Registrate</a>
    </div>
  </div>

</form>

    </div>
    </div>
</div>
<br><br><br>