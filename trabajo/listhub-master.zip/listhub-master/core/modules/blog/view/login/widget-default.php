        <div class="form-box" id="login-box">
            <div class="header">Ingresar</div>
            <form action="index.php?view=processlogin" method="post">
                <div class="body bg-gray">
                    <div class="form-group">
                        <input type="text" name="mail" class="form-control" placeholder="Nombre de usuario"/>
                    </div>
                    <div class="form-group">
                        <input type="password" name="password" class="form-control" placeholder="Password"/>
                    </div>          

                </div>
                <div class="footer">                                                               
                    <button type="submit" class="btn btn-primary btn-block">Iniciar Sesson</button>  
                    <!--
                    <p><a href="#">I forgot my password</a></p>
                    
                    <a href="register.html" class="text-center">Register a new membership</a>
                    -->
                </div>
            </form>
        </div>
